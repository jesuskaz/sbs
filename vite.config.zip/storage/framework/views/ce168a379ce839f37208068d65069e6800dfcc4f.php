<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <!-- Main Content -->
    <div class="main-content">
        <section class="section">
            <div class="row">
                <div class="col-12">

                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('message')); ?></li>
                        </div>
                    <?php endif; ?>

                    <?php if(session()->has('message2')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('message2')); ?></li>
                        </div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-header">
                            Ajouter un service
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <form method="POST" action="<?php echo e(route('admin.services.store')); ?>"
                                          enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>

                                        <div class="row">
                                            <div class="form-group col-6">
                                                <label>Image : .jpg, .png | max : 300Kb</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="fas fa-file-image"></i>
                                                        </div>
                                                    </div>
                                                    <input type="file" name="image" required class="form-control">
                                                </div>
                                            </div>

                                            <div class="form-group col-6">
                                                <label>Nom du service</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="fas fa-calculator"></i>
                                                        </div>
                                                    </div>
                                                    <input type="text" name="name" value="<?php echo e(old('name')); ?>" required
                                                           maxlength="128" class="form-control">
                                                </div>
                                            </div>
                                        </div>


                                        <div class="row">
                                            <div class="form-group col-6">
                                                <label>Categorie du service</label>
                                                <div class="input-group">
                                                    <div class="col-sm-12 col-md-12">
                                                        <select name="category_id" class="form-control selectric">
                                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group col-6">
                                                <label>Description du service</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <div class="input-group-text">
                                                            <i class="fas fa-list"></i>
                                                        </div>
                                                    </div>
                                                    <input type="text" name="description" value="<?php echo e(old('description')); ?>" required
                                                           maxlength="128" class="form-control">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group col-12">
                                            <button type="submit" class="btn btn-primary btn-lg btn-block">
                                                AJOUTER SERVICE
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/bcs/devs/sbs-web-application/resources/views/pages/admin/services/create.blade.php ENDPATH**/ ?>