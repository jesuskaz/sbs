CONNEXION
<?php /**PATH /Users/bcs/devs/sbs-web-application/resources/views/components/login-text.blade.php ENDPATH**/ ?>