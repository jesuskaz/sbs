<header class="">
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><h2>Supply  <em>Business </em> Service</h2></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item <?php if( (Request::url() === route('home'))): ?>

                    <?php echo e('active'); ?>


                    <?php endif; ?>">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>">Home
                            <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if((Request::url() === route('services'))): ?>

                        <?php echo e('active'); ?>


                        <?php endif; ?>" href="<?php echo e(route('services')); ?>">Nos Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if((Request::url() === route('about'))): ?>

                        <?php echo e('active'); ?>


                        <?php endif; ?>" href="<?php echo e(route('about')); ?>">Apropos Nous</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if((Request::url() === route('contact'))): ?>

                        <?php echo e('active'); ?>


                        <?php endif; ?>" href="<?php echo e(route('contact')); ?>">Contactez Nous</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<?php /**PATH /Users/bcs/devs/sbs-web-application/resources/views/pages/includes/navbar.blade.php ENDPATH**/ ?>