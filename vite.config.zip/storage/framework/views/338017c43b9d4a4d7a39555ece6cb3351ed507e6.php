<?php $__env->startSection('content'); ?>

<!-- ***** Preloader Start ***** -->
<div id="preloader">
    <div class="jumper">
        <div></div>
        <div></div>
        <div></div>
    </div>
</div>
<!-- ***** Preloader End ***** -->

<!-- Header -->
<?php echo $__env->make('pages.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Page Content -->
<div class="page-heading products-heading header-text" style="background-image: url(<?php echo e(asset('storage') .'/'. $image[0]); ?>);">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="text-content">
                    <h2>Ce que nous vous offrons comme services</h2>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="products">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="filters">
                    <ul>
                        <li class="active" data-filter="*">Tous les services</li>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li data-filter=".<?php echo e($category->id); ?>"><?php echo e($category->name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-12">
                <div class="filters-content">
                    <div class="row grid">
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-4 all <?php echo e($service->category_id); ?>">
                            <div class="product-item">
                                <a href="#"><img src="<?php echo e(asset('storage/'.$service->image->path)); ?>" alt=""></a>
                                <div class="down-content">
                                    <a href="#"><h4><?php echo e($service->name); ?></h4></a>
                                    <p><?php echo $service->description; ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>









        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bcs/devs/sbs-web-application/resources/views/pages/services.blade.php ENDPATH**/ ?>