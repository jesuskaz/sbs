<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <!-- Main Content -->
    <div class="main-content">
        <section class="section">
            <div class="row">
                <div class="col-12">

                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('message')); ?></li>
                        </div>
                    <?php endif; ?>

                    <?php if(session()->has('message2')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('message2')); ?></li>
                        </div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-header">
                            <h4>Liste des services</h4>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover" id="save-stage" style="width:100%;">
                                    <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Image</th>
                                        <th>Nom servicce</th>
                                        <th>Categorie</th>
                                        <th>Description</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($service->id); ?></td>
                                            <td>
                                                <a href="<?php echo e(asset('storage/'.$service->image->path)); ?>">
                                                    <img src="<?php echo e(asset('storage/'.$service->image->path)); ?>"
                                                         class="img-rounded" width="100px" height="100px" alt=""
                                                         srcset="">
                                                </a>
                                            </td>
                                            <td><?php echo e($service->name); ?></td>
                                            <td><?php echo e($service->categorie->name); ?></td>
                                            <td><?php echo e($service->description); ?></td>
                                            <td>
                                                <a href=""
                                                   class="btn btn-icon icon-left btn-success"><i class="fa fa-edit"
                                                                                                aria-hidden="true"></i>
                                                    Modifier</a>
                                                <a href=""
                                                   class="btn btn-icon icon-left btn-danger"><i class="fa fa-trash"
                                                                                                aria-hidden="true"></i>
                                                    Supprimer</a>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/bcs/devs/sbs-web-application/resources/views/pages/admin/services/index.blade.php ENDPATH**/ ?>