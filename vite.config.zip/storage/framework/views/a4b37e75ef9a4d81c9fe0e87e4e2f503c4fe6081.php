<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-primary btn-lg btn-block'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /Users/bcs/devs/sbs-web-application/resources/views/components/primary-button.blade.php ENDPATH**/ ?>