<div class="card card-primary">
    <div class="card-header">
        <h4><?php echo e($text); ?></h4>
    </div>
    <div class="card-body">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH /Users/bcs/devs/sbs-web-application/resources/views/components/auth-card.blade.php ENDPATH**/ ?>