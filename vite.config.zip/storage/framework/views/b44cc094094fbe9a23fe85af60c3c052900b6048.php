<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <!-- Main Content -->
    <div class="main-content">
        <section class="section">
            <div class="row">
                <div class="col-12">

                    <?php if(session('success') == true): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('message')); ?></li>
                        </div>
                    <?php elseif(session('success') === false): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = session('message'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(Session::get('message2')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('message2')); ?></li>
                        </div>
                    <?php endif; ?>

                    <div class="card">
                        <div class="card-header">
                            Modifier une categorie de service
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <form method="POST" action="<?php echo e(route('admin.categories.update', $category)); ?>"
                                          enctype="multipart/form-data">
                                        <?php echo method_field('put'); ?>
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label>Image : .jpg, .png | max : 300Kb</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">
                                                        <i class="fas fa-file-image"></i>
                                                    </div>
                                                </div>
                                                <input type="file" name="image" required class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Nom de la categorie</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">
                                                        <i class="fas fa-calendar"></i>
                                                    </div>
                                                </div>
                                                <input type="text" name="name" value="<?php echo e($category->name); ?>" required
                                                       placeholder="Nom de la categorie" maxlength="128" class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group col-12">
                                            <button type="submit" class="btn btn-primary btn-lg btn-block">
                                                AJOUTER CATEGORIE
                                            </button>
                                        </div>
                                    </form>
                                </div>

                                <div class="col-md-6">
                                    <div class="ml-lg-5">
                                        <a href="<?php echo e(asset('storage/'.$category->image->path)); ?>">
                                            <img src="<?php echo e(asset('storage/'.$category->image->path)); ?>"
                                                 class="img-rounded" width="400px" height="400px" alt=""
                                                 srcset="">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /Users/bcs/devs/sbs-web-application/resources/views/pages/admin/categories/edit.blade.php ENDPATH**/ ?>