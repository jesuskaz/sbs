@include('pages.includes.header')


@yield('content')


@include('pages.includes.footer')
