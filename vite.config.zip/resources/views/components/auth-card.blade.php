<div class="card card-primary">
    <div class="card-header">
        <h4>{{ $text }}</h4>
    </div>
    <div class="card-body">
        {{ $slot }}
    </div>
</div>
