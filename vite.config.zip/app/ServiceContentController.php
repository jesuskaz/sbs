<?php

class ServiceContentController
{

}
