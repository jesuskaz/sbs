<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Image;
use App\Models\Service;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $services = Service::all();

        $categories = Category::all();

        $homeImages = $this->getHomeImages();

        return view('pages.index', compact('homeImages', 'categories'));
    }

    private function getHomeImages()
    {
        return Image::where('path', 'like', '%images/slider%')->get()->pluck('path')->all();
    }
}
