<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Image;
use App\Models\Service;
use Illuminate\Http\Request;

class ServicesController extends Controller
{
    public function index()
    {
        $services = Service::all();

        $image = $this->getOldImages();

        $categories = Category::with('services')->get();

        return view('pages.services', compact('categories', 'services', 'image'));
    }

    private function getOldImages(): array
    {
        return Image::where('path', 'like', '%images/services%')->get()->pluck('path')->all();
    }
}
